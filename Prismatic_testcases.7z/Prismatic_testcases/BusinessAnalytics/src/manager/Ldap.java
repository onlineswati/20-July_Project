package manager;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.novell.ldap.LDAPConnection;
import com.novell.ldap.LDAPException;

public class Ldap {

	public static Properties prop = new Properties();

	static {
		try {
			
			InputStream inputStream=Ldap.class.getClassLoader().getResource("./config/LdapSettings.properties").openStream();
			prop.load(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		System.out.println(validate("swati", ""));
	}

	public static boolean validate(String user, String password) {
		System.out.println("Ldap.validate()");
		if (StringUtils.isBlank(password) || StringUtils.isBlank(user)) {
			return false;
		}
		int ldapPort = Integer.parseInt(prop.get("ldapPort").toString());

		int ldapVersion = Integer.parseInt(prop.get("ldapVersion").toString());

		String ldapHost = prop.get("ldapHost").toString();

		//String loginDN = "uid=bdteam,ou=tableau,dc=highmark,dc=in";
         String loginDN = "uid=" + user + "," + prop.get("base");
		// "uid=bdteam,ou=tableau,ou=groups,dc=highmark,dc=in";

		LDAPConnection lc = new LDAPConnection();

		try {
			lc.connect(ldapHost, ldapPort);
            System.out.println("Connection success");
			
			System.out.println("("+loginDN +")");
			System.out.println("("+password+")");
			
			lc.bind(ldapVersion, loginDN, password.getBytes("UTF8"));
			
			
			lc.disconnect();
			return true;
		}

		catch (LDAPException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}

		catch (UnsupportedEncodingException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}
	}

	public static boolean validate1(String user, String password) {
		System.out.println("Ldap.validate1()");
		if (StringUtils.isBlank(password) || StringUtils.isBlank(user)) {
			return false;
		}
		int ldapPort = Integer.parseInt(prop.get("ldapPort1").toString());

		int ldapVersion = Integer.parseInt(prop.get("ldapVersion1").toString());

		String ldapHost = prop.get("ldapHost1").toString();

	//	String loginDN = "uid=bdteam,ou=tableau,dc=highmark,dc=in";

		 String loginDN = "uid=" + user + "," + prop.get("base");
		
		// "uid=bdteam,ou=tableau,ou=groups,dc=highmark,dc=in";

		LDAPConnection lc = new LDAPConnection();

		try {

			lc.connect(ldapHost, ldapPort);

			lc.bind(ldapVersion, loginDN, password.getBytes("UTF8"));

			lc.disconnect();
			return true;
		}

		catch (LDAPException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}

		catch (UnsupportedEncodingException e) {

			System.out.println("Error: " + e.toString());
			return false;
		}
	}

}
