
$(window).load(function(){

  $('.containmain').slideDown(500);

});

$(window).ready(function(){
  $(".topform , .bottomform").focus(function() {
    $(this).css({'background-image': 'none'});
});
  
  
  if ($('.topform').is(':empty')){
  
  $(".topform").focusout(function(){
   imageUrl = ('images/16612.png');
    $(this).css('background-image', 'url(' + imageUrl + ')'); 
  });
    
  } else if ($('.topform').not(':empty')){
  
     $(this).css('background-image', 'none'); 
    
  }
  
  
    $(".bottomform").focusout(function(){
   imageUrl = ('images/25239.png');
    $(this).css('background-image', 'url(' + imageUrl + ')'); 
  });
   
});